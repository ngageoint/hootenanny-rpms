<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>Project-Id-Version: GPSBabel command line program
POT-Creation-Date: 2005-11-19 01:14
PO-Revision-Date: 2008-04-26 21:18+0100
Last-Translator: oliskoli &lt;o.b.klein@gpsbabel.org&gt;
MIME-Version: 1.0
Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: 8bit
X-Generator: dxgettext 1.2.1
Language-Team:  &lt;o.b.klein@gpsbabel.org&gt;
X-Poedit-SourceCharset: iso-8859-1
X-Poedit-Language: German
X-Poedit-Country: GERMANY
</translation>
    </message>
    <message>
        <source>(integer sec or &apos;auto&apos;) Barograph to GPS time diff</source>
        <translation type="obsolete">Zeitdifferent zwischen Barograph und GPS (ganzz. Sekunden oder &apos;auto&apos;)</translation>
    </message>
    <message>
        <source>(USR input) Break segments into separate tracks</source>
        <translation type="obsolete">USR Eingabe: Segmente in seperate Tracks aufteilen</translation>
    </message>
    <message>
        <source>(USR output) Merge into one segmented track</source>
        <translation type="obsolete">USR-Ausgabe: zu einem segmentierten Track zusammenfassen</translation>
    </message>
    <message>
        <source>Ad-hoc closed icon name</source>
        <translation type="obsolete">Icon allgemein fÃ¼r &quot;geschlossen&quot;</translation>
    </message>
    <message>
        <source>Ad-hoc open icon name</source>
        <translation type="obsolete">Icon allgemein fÃ¼r &quot;offen&quot;</translation>
    </message>
    <message>
        <source>After output job done sleep n second(s)</source>
        <translation type="obsolete">Pausiere im AnschluÃŸ n sekunde(n)</translation>
    </message>
    <message>
        <source>Allow whitespace synth. shortnames</source>
        <translation type="obsolete">Erlaube Leerzeichen in Kurznamen</translation>
    </message>
    <message>
        <source>Altitudes are absolute and not clamped to ground</source>
        <translation type="obsolete">Absolute HÃ¶henangaben (nicht bodenverbunden)</translation>
    </message>
    <message>
        <source>Append icon_descr to description</source>
        <translation type="obsolete">Erweitere Beschreibung um Symbolbeschreibung</translation>
    </message>
    <message>
        <source>Base URL for link tag in output</source>
        <translation type="obsolete">Basis-URL fÃ¼r VerknÃ¼pfungseintrag </translation>
    </message>
    <message>
        <source>Basename prepended to URL on output</source>
        <translation type="obsolete">Basis-Adresse fÃ¼r erzeugte URL&apos;s</translation>
    </message>
    <message>
        <source>Bitmap of categories</source>
        <translation type="obsolete">Mehrfachkategorie, als Dezimal- oder Hexadezimalwert</translation>
    </message>
    <message>
        <source>Category name (Cache)</source>
        <translation type="obsolete">Kategoriename (Cache)</translation>
    </message>
    <message>
        <source>Category number to use for written waypoints</source>
        <translation type="obsolete">Benutze Kategorie # beim Schreiben von Wegpunkten  (1..16)</translation>
    </message>
    <message>
        <source>Color for lines or mapnotes</source>
        <translation type="obsolete">Farbe fÃ¼r Linien oder Kartenangaben</translation>
    </message>
    <message>
        <source>Command unit to power itself down</source>
        <translation type="obsolete">GerÃ¤t im AnschluÃŸ abschalten</translation>
    </message>
    <message>
        <source>Complete date-free tracks with given date (YYYYMMDD).</source>
        <translation type="obsolete">Komplettiere Tracks ohne Datumsangaben mit Datum ... (YYYYMMDD)</translation>
    </message>
    <message>
        <source>Create unique waypoint names (default = yes)</source>
        <translation type="obsolete">Erzeuge eindeutige Wegpunktnamen (Vorgabe: JA)</translation>
    </message>
    <message>
        <source>Create waypoints from geocache log entries</source>
        <translation type="obsolete">Erzeuge Wegpunkte aus Geocache Log-EintrÃ¤gen</translation>
    </message>
    <message>
        <source>Database name</source>
        <translation type="obsolete">Interner Name fÃ¼r die Palm/OS Datenbank</translation>
    </message>
    <message>
        <source>Database name (filename)</source>
        <translation type="obsolete">Datenbankname (Dateiname)</translation>
    </message>
    <message>
        <source>Datum (default=NAD27)</source>
        <translation type="obsolete">GPS-Datum (Vorgabe: NAD27)</translation>
    </message>
    <message>
        <source>Days after which points are considered old</source>
        <translation type="obsolete">Anzahl an Tagen, nach denen Punkte als alt betrachtet werden</translation>
    </message>
    <message>
        <source>Decimal seconds to pause between groups of strings</source>
        <translation type="obsolete">Pause (in Sekunden) zwischen Zeilengruppen</translation>
    </message>
    <message>
        <source>Default category on output</source>
        <translation type="obsolete">Standardkategorie beim Schreiben</translation>
    </message>
    <message>
        <source>Default category on output (1..16)</source>
        <translation type="obsolete">Standard Kategorie (1..16)</translation>
    </message>
    <message>
        <source>Default icon name</source>
        <translation type="obsolete">Standard Symbol</translation>
    </message>
    <message>
        <source>Default location</source>
        <translation type="obsolete">Vorgabestandort</translation>
    </message>
    <message>
        <source>Default proximity</source>
        <translation type="obsolete">Vorgabe-AnnÃ¤herungsabstand</translation>
    </message>
    <message>
        <source>Default speed</source>
        <translation type="obsolete">Standardgeschwindigkeit</translation>
    </message>
    <message>
        <source>Default speed for waypoints (knots/hr)</source>
        <translation type="obsolete">Vorgabegeschwindigkeit (Knoten/h)</translation>
    </message>
    <message>
        <source>Degrees output as &apos;ddd&apos;, &apos;dmm&apos;(default) or &apos;dms&apos;</source>
        <translation type="obsolete">Schreibe Gradangaben in &apos;ddd&apos;, &apos;dmm&apos; (Vorgabe) oder &apos;dms&apos; (Gitter)</translation>
    </message>
    <message>
        <source>Delete all routes</source>
        <translation type="obsolete">LÃ¶sche alle Routen</translation>
    </message>
    <message>
        <source>Delete all track points</source>
        <translation type="obsolete">LÃ¶sche alle Trackpunkte</translation>
    </message>
    <message>
        <source>Delete all waypoints</source>
        <translation type="obsolete">LÃ¶sche alle Wegpunkte</translation>
    </message>
    <message>
        <source>Display labels on track and routepoints  (default = 1)</source>
        <translation type="obsolete">Zeige Beschriftung bei Track- und Routenpunkten (Vorgabe: 1)</translation>
    </message>
    <message>
        <source>Distance unit [m=metric, s=statute]</source>
        <translation type="obsolete">Entfernungsangaben [m=Metrisch, s=Statute]</translation>
    </message>
    <message>
        <source>Do not add geocache data to description</source>
        <translation type="obsolete">Keine Geocache-Daten zur Beschreibung hinzufÃ¼gen</translation>
    </message>
    <message>
        <source>Do not add URLs to description</source>
        <translation type="obsolete">HÃ¤nge keine URL&apos;s an die Beschreibung an</translation>
    </message>
    <message>
        <source>Don&apos;t show gpi bitmap on device</source>
        <translation type="obsolete">Zeige keine Bitmap (Icon) auf dem GPS</translation>
    </message>
    <message>
        <source>Draw extrusion line from trackpoint to ground</source>
        <translation type="obsolete">Zeichne eine Verbindungslinie vom Trackpunkt zum Erdboden</translation>
    </message>
    <message>
        <source>Drop route points that do not have an equivalent waypoint (hidden points)</source>
        <translation type="obsolete">LÃ¶sche versteckte Wegpunkte (automatisch berechnete Routenpunkte)</translation>
    </message>
    <message>
        <source>Enable alerts on speed or proximity distance</source>
        <translation type="obsolete">Aktiviere Alarm fÃ¼r AnnÃ¤herung and Geschwindigkeit</translation>
    </message>
    <message>
        <source>Encrypt hints using ROT13</source>
        <translation type="obsolete">VerschlÃ¼sselung mit ROT13</translation>
    </message>
    <message>
        <source>Encrypt hints with ROT13</source>
        <translation type="obsolete">VerschlÃ¼sselung mit ROT13</translation>
    </message>
    <message>
        <source>Erase device data after download</source>
        <translation type="obsolete">Nach Download Daten auf dem GerÃ¤t lÃ¶schen</translation>
    </message>
    <message>
        <source>Export linestrings for tracks and routes</source>
        <translation type="obsolete">Exportiere Linendaten (linestrings) fÃ¼r Tracks und Routen (Vorgabe: JA)</translation>
    </message>
    <message>
        <source>Export placemarks for tracks and routes</source>
        <translation type="obsolete">Exportiere Markierungen fÃ¼r Tracks und Routen</translation>
    </message>
    <message>
        <source>Full path to XCSV style file</source>
        <translation type="obsolete">Pfad zur &apos;XCSV-Style&apos;-Datei</translation>
    </message>
    <message>
        <source>Generate # points</source>
        <translation type="obsolete">Erzeuge # Punkte</translation>
    </message>
    <message>
        <source>Generate file with lat/lon for centering map</source>
        <translation type="obsolete">Erzeuge Datei mit Breiten- und LÃ¤ngengradwerten (fÃ¼r Kartenzentrierung)</translation>
    </message>
    <message>
        <source>Give points (waypoints/route points) a default radius (proximity)</source>
        <translation type="obsolete">Gebe Wegpunkten/Routenpunkten diesen Radius </translation>
    </message>
    <message>
        <source>GPS datum (def. WGS 84)</source>
        <translation type="obsolete">GPS-Datum (Vorgabe: WGS 84)</translation>
    </message>
    <message>
        <source>Height in pixels of map</source>
        <translation type="obsolete">KartenhÃ¶he in Pixel</translation>
    </message>
    <message>
        <source>Ignore event marker icons on read</source>
        <translation type="obsolete">Ignoriere Ereignis-Icons beim Lesen</translation>
    </message>
    <message>
        <source>Include extended data for trackpoints (default = 1)</source>
        <translation type="obsolete">Erweiterte Daten in Trackpoints mit einbeziehen (Vorgabe = 1)</translation>
    </message>
    <message>
        <source>Include groundspeak logs if present</source>
        <translation type="obsolete">Groundspeak Log&apos;s beifÃ¼gen (wenn vorhandan)</translation>
    </message>
    <message>
        <source>Include major turn points (with description) from calculated route</source>
        <translation type="obsolete">Beziehe HauptrichtungsÃ¤nderungen (Ansage vorhanden) mit ein</translation>
    </message>
    <message>
        <source>Include only via stations in route</source>
        <translation type="obsolete">Ãœbernehme nur Stationspunkte (&apos;viastations&apos;) der Route</translation>
    </message>
    <message>
        <source>Include short name in bookmarks</source>
        <translation type="obsolete">Ãœbernehme Kurznamen in Lesezeichen</translation>
    </message>
    <message>
        <source>Index of name field in .dbf</source>
        <translation type="obsolete">Index des Namensfeldes innerhalb der .dbf</translation>
    </message>
    <message>
        <source>Index of route (if more than one in source)</source>
        <translation type="obsolete">Index des Route (falls mehrere im Eingabeformat)</translation>
    </message>
    <message>
        <source>Index of route to write (if more than one in source)</source>
        <translation type="obsolete">Routen-Index (wenn mehrere vorhanden)</translation>
    </message>
    <message>
        <source>Index of route/track to write (if more than one in source)</source>
        <translation type="obsolete">Route oder Track-Index (wenn mehrere vorhanden)</translation>
    </message>
    <message>
        <source>Index of track (if more than one in source)</source>
        <translation type="obsolete">Index des Tracks (falls mehrere im Eingabeformat)</translation>
    </message>
    <message>
        <source>Index of track to write (if more than one in source)</source>
        <translation type="obsolete">Track-Index (wenn mehrere vorhanden)</translation>
    </message>
    <message>
        <source>Index of URL field in .dbf</source>
        <translation type="obsolete">Index der URL innerhalb der .dbf</translation>
    </message>
    <message>
        <source>Indicate direction of travel in track icons (default = 0)</source>
        <translation type="obsolete">Erzeuge spezielle Icons (Richtungspfeile)</translation>
    </message>
    <message>
        <source>Infrastructure closed icon name</source>
        <translation type="obsolete">Icon &quot;Komplex (Infrastruktur) geschlossen&quot;</translation>
    </message>
    <message>
        <source>Infrastructure open icon name</source>
        <translation type="obsolete">Icon &quot;Komplex (Infrastruktur) offen&quot;</translation>
    </message>
    <message>
        <source>Keep turns if simplify filter is used</source>
        <translation type="obsolete">Erhalte Abbiegungen bei Benutzung des Simplify-Filters (Vereinfachen)</translation>
    </message>
    <message>
        <source>Length of generated shortnames</source>
        <translation type="obsolete">Maximale LÃ¤nge der generierten Kurznamen</translation>
    </message>
    <message>
        <source>Length of generated shortnames (default 16)</source>
        <translation type="obsolete">Maximale LÃ¤nge der zu generierten Kurznamen</translation>
    </message>
    <message>
        <source>Line color, specified in hex AABBGGRR</source>
        <translation type="obsolete">Linienfarbe (hex. Angabe in Form AABBGGRR)</translation>
    </message>
    <message>
        <source>Make synth. shortnames unique</source>
        <translation type="obsolete">Eindeutige Kurznamen erzeugen</translation>
    </message>
    <message>
        <source>MapSend version TRK file to generate (3,4)</source>
        <translation type="obsolete">Generiere TRK-Datei in MapSend-Version # (3,4)</translation>
    </message>
    <message>
        <source>Margin for map.  Degrees or percentage</source>
        <translation type="obsolete">Begrenzung der Karte (in Grad oder Prozent)</translation>
    </message>
    <message>
        <source>Marker type for new points</source>
        <translation type="obsolete">Markierungstyp fÃ¼r neue Punkte</translation>
    </message>
    <message>
        <source>Marker type for old points</source>
        <translation type="obsolete">Markierungstyp fÃ¼r alte Punkte</translation>
    </message>
    <message>
        <source>Marker type for unfound points</source>
        <translation type="obsolete">Markierungstyp fÃ¼r nicht gefundene Punkte</translation>
    </message>
    <message>
        <source>Max length of waypoint name to write</source>
        <translation type="obsolete">Max. LÃ¤nge der zu schreibenden Wegpunktnamen</translation>
    </message>
    <message>
        <source>Max number of comments to write (maxcmts=200)</source>
        <translation type="obsolete">Maximale Anzahl an Kommentaren fÃ¼r die Ausgabe</translation>
    </message>
    <message>
        <source>Max shortname length when used with -s</source>
        <translation type="obsolete">Maximale LÃ¤nge der generierten Kurznamen</translation>
    </message>
    <message>
        <source>Max synthesized shortname length</source>
        <translation type="obsolete">Maximale LÃ¤nge der generierten Kurznamen</translation>
    </message>
    <message>
        <source>Merge output with existing file</source>
        <translation type="obsolete">Ausgabe in existierende Datei einfÃ¼gen</translation>
    </message>
    <message>
        <source>MTK compatible CSV output file</source>
        <translation type="obsolete">Ausgabe-CSV-Datei kompatibel zum MTK-Datalogger</translation>
    </message>
    <message>
        <source>Name of the &apos;unassigned&apos; category</source>
        <translation type="obsolete">Name der &apos;unassigned&apos;-Kategorie</translation>
    </message>
    <message>
        <source>New name for the route</source>
        <translation type="obsolete">Name der neuen Route</translation>
    </message>
    <message>
        <source>No separator lines between waypoints</source>
        <translation type="obsolete">keine Trennlinien zwischen den Wegpunkten</translation>
    </message>
    <message>
        <source>No whitespace in generated shortnames</source>
        <translation type="obsolete">Leerzeichen in Kurznamen unterdrÃ¼cken</translation>
    </message>
    <message>
        <source>Non-stealth encrypted icon name</source>
        <translation type="obsolete">Sichtbar verschlÃ¼sselter Symbolname</translation>
    </message>
    <message>
        <source>Non-stealth non-encrypted icon name</source>
        <translation type="obsolete">Sichtbar und unverschlÃ¼sselter Symbolname</translation>
    </message>
    <message>
        <source>Numeric value of bitrate (baud=4800)</source>
        <translation type="obsolete">Baudrate (Vorgabe: 4800)</translation>
    </message>
    <message>
        <source>Omit Placer name</source>
        <translation type="obsolete">Placername auslassen</translation>
    </message>
    <message>
        <source>Only read turns; skip all other points</source>
        <translation type="obsolete">Lese nur Abbiegungen und ignoriere alle sonstigen Punkte</translation>
    </message>
    <message>
        <source>Path to HTML style sheet</source>
        <translation type="obsolete">Pfad zum HTML-Style-Sheet</translation>
    </message>
    <message>
        <source>Precision of coordinates</source>
        <translation type="obsolete">PrÃ¤zision der Koordinaten (Anzahl Nachkommastellen)</translation>
    </message>
    <message>
        <source>Proximity distance</source>
        <translation type="obsolete">StandardmÃ¤ÃŸiger AnnÃ¤herungsabstand</translation>
    </message>
    <message>
        <source>Radius for circles</source>
        <translation type="obsolete">Kreisradius</translation>
    </message>
    <message>
        <source>Radius of our big earth (default 6371000 meters)</source>
        <translation type="obsolete">Erdradius in Meter (Vorgabe: 6371000 Meter)</translation>
    </message>
    <message>
        <source>Read control points as waypoint/route/none</source>
        <translation type="obsolete">Lese Kontrollpunkte als Wegpunkt/Route/nichts</translation>
    </message>
    <message>
        <source>Read/Write date format (i.e. DDMMYYYY)</source>
        <translation type="obsolete">Datumsformat fÃ¼r Ein-/Ausgabe (z.B. DDMMYYYY)</translation>
    </message>
    <message>
        <source>Read/Write date format (i.e. yyyy/mm/dd)</source>
        <translation type="obsolete">Datumsformat (z.B. DD.MM.YYYY)</translation>
    </message>
    <message>
        <source>Read/write GPGGA sentences</source>
        <translation type="obsolete">Schreibe/Lese GPGGA Sequenzen</translation>
    </message>
    <message>
        <source>Read/write GPGSA sentences</source>
        <translation type="obsolete">Schreibe/Lese GPGSA Sequenzen</translation>
    </message>
    <message>
        <source>Read/write GPRMC sentences</source>
        <translation type="obsolete">Schreibe/Lese GPRMC Sequenzen</translation>
    </message>
    <message>
        <source>Read/write GPVTG sentences</source>
        <translation type="obsolete">Schreibe/Lese GPVTG Sequenzen</translation>
    </message>
    <message>
        <source>Read/Write time format (i.e. HH:mm:ss xx)</source>
        <translation type="obsolete">Zeitformat (z.B. HH:mm:ss xx)</translation>
    </message>
    <message>
        <source>Retain at most this number of position points  (0 = unlimited)</source>
        <translation type="obsolete">Behalte hÃ¶chstens diese Anzahl an Positionspunkten (0 = kein Limit)</translation>
    </message>
    <message>
        <source>Return current position as a waypoint</source>
        <translation type="obsolete">Ãœbertrage aktuelle Position als Wegpunkt</translation>
    </message>
    <message>
        <source>Road type changes</source>
        <translation type="obsolete">StraÃŸentyp-Wechsel</translation>
    </message>
    <message>
        <source>Set waypoint name to source filename.</source>
        <translation type="obsolete">Erzeuge den Wegpunktnamen an Hand des Dateinames</translation>
    </message>
    <message>
        <source>Shortname is MAC address</source>
        <translation type="obsolete">Kurzname ergibt sich aus MAC-Adresse</translation>
    </message>
    <message>
        <source>Speed in bits per second of serial port (baud=4800)</source>
        <translation type="obsolete">Ãœbertragungsrate des seriellen Ports in Bits/Sekunde (Vorgabe: baud=4800)</translation>
    </message>
    <message>
        <source>Split input into separate files</source>
        <translation type="obsolete">Teile gelesene Daten in seperate Dateien</translation>
    </message>
    <message>
        <source>Split into multiple routes at turns</source>
        <translation type="obsolete">Route an Abbiegungen teilen</translation>
    </message>
    <message>
        <source>Starting seed of the internal number generator</source>
        <translation type="obsolete">Startwert fÃ¼r internen Zufallszahlengenerator</translation>
    </message>
    <message>
        <source>Stealth encrypted icon name</source>
        <translation type="obsolete">Unsichtbar verschlÃ¼sselter Symbolname</translation>
    </message>
    <message>
        <source>Stealth non-encrypted icon name</source>
        <translation type="obsolete">Unsichtbarer unverschlÃ¼sselter Symbolname</translation>
    </message>
    <message>
        <source>String to separate concatenated address fields (default=&quot;, &quot;)</source>
        <translation type="obsolete">Trennzeichen fÃ¼r zusammengefÃ¼gte Adressfelder (Vorgabe: &quot;, &quot;)</translation>
    </message>
    <message>
        <source>Suppress labels on generated pins</source>
        <translation type="obsolete">UnterdÃ¼cke Kennzeichnung fÃ¼r erzeugte Pins</translation>
    </message>
    <message>
        <source>Suppress retired geocaches</source>
        <translation type="obsolete">UnterdrÃ¼cke zurÃ¼ckgezogene (?) Geocaches</translation>
    </message>
    <message>
        <source>Suppress separator lines between waypoints</source>
        <translation type="obsolete">Keine Trennlinien zwischen den Wegpunkten</translation>
    </message>
    <message>
        <source>Suppress use of handshaking in name of speed</source>
        <translation type="obsolete">Kein &apos;Handshaking&apos; (im Namen der Geschwindigkeit)</translation>
    </message>
    <message>
        <source>Suppress whitespace in generated shortnames</source>
        <translation type="obsolete">Keine Leerzeichen in Kurznamen</translation>
    </message>
    <message>
        <source>Symbol to use for point data</source>
        <translation type="obsolete">Symbol fÃ¼r Punkte</translation>
    </message>
    <message>
        <source>Sync GPS time to computer time</source>
        <translation type="obsolete">Synchronisiere PC-Uhr mit dem GPS (PC -&gt; GPS)</translation>
    </message>
    <message>
        <source>Synthesize track times</source>
        <translation type="obsolete">Erzeuge Tracknamen</translation>
    </message>
    <message>
        <source>Target GPX version for output</source>
        <translation type="obsolete">Schreibe in GPX-Version (1.0 oder 1.1)</translation>
    </message>
    <message>
        <source>Temperature unit [c=Celsius, f=Fahrenheit]</source>
        <translation type="obsolete">Temperatureinheit [c=Celsius, F=Fahrenheit]</translation>
    </message>
    <message>
        <source>The icon description is already the marker</source>
        <translation type="obsolete">Die Symbolbeschreibung ist bereits die Markierung</translation>
    </message>
    <message>
        <source>Treat waypoints as icons on write</source>
        <translation type="obsolete">Behandle Wegpunkte als Icons beim Schreiben</translation>
    </message>
    <message>
        <source>Type of .an1 file</source>
        <translation type="obsolete">.an1 Dateityp</translation>
    </message>
    <message>
        <source>Units for altitude (f)eet or (m)etres</source>
        <translation type="obsolete">HÃ¶henangaben in FuÃŸ oder Meter (&apos;f&apos; oder &apos;m&apos;)</translation>
    </message>
    <message>
        <source>Units used for names with @speed (&apos;s&apos;tatute or &apos;m&apos;etric)</source>
        <translation type="obsolete">Einheit fÃ¼r Geschwindigkeit in Wegpunkten [...@30]  ( &apos;s&apos;tatute oder &apos;m&apos;etrisch)</translation>
    </message>
    <message>
        <source>Units used when writing comments (&apos;s&apos;tatute or &apos;m&apos;etric)</source>
        <translation type="obsolete">Einheit innerhalb von Kommentaren ( &apos;s&apos;tatute oder &apos;m&apos;etrisch)</translation>
    </message>
    <message>
        <source>UPPERCASE synth. shortnames</source>
        <translation type="obsolete">Erzeuge Kurznamen in GroÃŸbuchstaben</translation>
    </message>
    <message>
        <source>Use depth values on output (default is ignore)</source>
        <translation type="obsolete">Tiefenangaben mit ausgeben (normalerweise ausgeschaltet)</translation>
    </message>
    <message>
        <source>Use proximity values on output (default is ignore)</source>
        <translation type="obsolete">Benutze Proximity-Werte bei der Ausgabe (Vorgabe: NEIN)</translation>
    </message>
    <message>
        <source>Use shortname instead of description</source>
        <translation type="obsolete">Benutze den Kurznamen anstelle der Beschreibung</translation>
    </message>
    <message>
        <source>Use specified bitmap on output</source>
        <translation type="obsolete">Benutze spezifische Bitmap (.BMP) fÃ¼r die Ausgabe</translation>
    </message>
    <message>
        <source>Version of gdb file to generate (1..3)</source>
        <translation type="obsolete">Schreibe GDB-Version 1, 2 oder 3</translation>
    </message>
    <message>
        <source>Version of mapsource file to generate (3,4,5)</source>
        <translation type="obsolete">Schreibe MapSource Datei in Version ... (3,4 oder 5)</translation>
    </message>
    <message>
        <source>Waypoint background color</source>
        <translation type="obsolete">Wegpunkt Hintergrundfarbe</translation>
    </message>
    <message>
        <source>Waypoint foreground color</source>
        <translation type="obsolete">Wegpunkt Vordergrundfarbe</translation>
    </message>
    <message>
        <source>Waypoint type</source>
        <translation type="obsolete">Wegpunkt Typ</translation>
    </message>
    <message>
        <source>Width in pixels of map</source>
        <translation type="obsolete">Kartenbreite in Pixel</translation>
    </message>
    <message>
        <source>Width of lines, in pixels</source>
        <translation type="obsolete">LinienhÃ¶he in Pixel</translation>
    </message>
    <message>
        <source>Write additional node tag key/value pairs</source>
        <translation type="obsolete">Schreibe zusÃ¤tzliche Wegpunkt (node) Informationspaare (tags)</translation>
    </message>
    <message>
        <source>Write additional way tag key/value pairs</source>
        <translation type="obsolete">Schreibe zusÃ¤tzliche Routen (way) Informationspaare (tags)</translation>
    </message>
    <message>
        <source>Write all tracks into one file</source>
        <translation type="obsolete">Schreibe alle Tracks in eine Datei</translation>
    </message>
    <message>
        <source>Write description to address field</source>
        <translation type="obsolete">Platziere die Beschreibung im Adressfeld</translation>
    </message>
    <message>
        <source>Write each waypoint in a separate file</source>
        <translation type="obsolete">Schreibe jeden Wegpunkt in eine separate Datei</translation>
    </message>
    <message>
        <source>Write notes to address field</source>
        <translation type="obsolete">Schreibe Kommentar (Notizen) in das Adressfeld</translation>
    </message>
    <message>
        <source>Write position to address field</source>
        <translation type="obsolete">Platziere die Koordinaten im Adressfeld</translation>
    </message>
    <message>
        <source>Write position using this grid.</source>
        <translation type="obsolete">Erzeuge Koordinaten unter Benutzung dieses Gitters (Grids).</translation>
    </message>
    <message>
        <source>Write timestamps with offset x to UTC time</source>
        <translation type="obsolete">Schreibe Zeitstempel relativ zur UTC + x</translation>
    </message>
    <message>
        <source>Write tracks compatible with Carto Exploreur</source>
        <translation type="obsolete">Erzeuge Tracks ohne Titel (kompatibel zu &quot;Carto Exploreur&quot;)</translation>
    </message>
    <message>
        <source>Write tracks for Gisteq Phototracker</source>
        <translation type="obsolete">Schreibe Tracks fÃ¼r &quot;Gisteq Phototracker&quot;</translation>
    </message>
    <message>
        <source>Zoom level to reduce points</source>
        <translation type="obsolete">VergrÃ¶ÃŸerungsfakter um Punkte zu unterdrÃ¼cken</translation>
    </message>
</context>
<context>
    <name>AboutDlg</name>
    <message>
        <source>About GPSBabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt; font-weight:600;&quot;&gt;$appname$&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;$babelfeversion$&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;Copyright (C) 2009-2016 Robert Lipe&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;GUI designed and contributed by  S. Khai Mong&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;LGPL Crystal Icons by Elvarado Coehlo&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;(Using backend $babelversion$)&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;$upgradetestmode$&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;Installation ID: $installationId$&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;This program is free software; you can redistribute it and/or  modify it under the terms of the GNU General Public License as  published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdvUi</name>
    <message>
        <source>Global Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create smart shortened names. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synthesize short names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert character set encoding between input and output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable character set transformation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview in Google Maps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debugging diagnostics.  
Higher number provides more deitaled diagnostics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debugging Diagnostics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set all format input/output options to default values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Format Options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Donate</name>
    <message>
        <source>Support GPSBabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Of course, if you&apos;ve already contributed  to the project or you just can&apos;t help the project, please check the box below to never see this message again.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never show this message again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No, Thanks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;GPSBabel is free software built and supported by volunteers. It consumes vast amounts of time to create and support the software as well as money for mapping programs, GPS receivers, and development fixtures. Please see how you can &lt;a href=&quot;https://www.gpsbabel.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;contribute time or via PayPal (no account needed).&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDlgManager</name>
    <message>
        <source>Select input file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select output file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilterDialog</name>
    <message>
        <source>Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waypoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Routes &amp; Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to reset all filter options to default values?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilterDlg</name>
    <message>
        <source>Data Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data filters process and transform the data between input and output files or devices. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GMapDialog</name>
    <message>
        <source>meters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>feet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>miles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length: %1 %2
  %3 %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lat: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lng: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desc: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cmt: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ele: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Points: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waypoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show All Waypoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide All Waypoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expand All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collapse All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show All Routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide All Routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show All Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide All Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Only This Waypoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Only This Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Only This Route</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GMapDlg</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Input </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If selected, input is from a file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If selected, input is from a device or GPS unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input data format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse for one or more input files. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Name(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of port to which input device is connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options for the selected input format. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If selected, translate waypoints.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waypoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If selected, translate routes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If selected, translate tracks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data Filters between input and output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More translation options. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If selected, output is to a file. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If selected, output is to a device or GPS unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse for an output file name. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of port to which output device is connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options for the selected output format. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output of GPSBabel translation process. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GPSBabel Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About GPSBabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select one or more input files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error reading format configuration.  Check that the backend program &quot;gpsbabel&quot; is properly installed and is in the current PATH

This program cannot continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Some file/device formats were not found during initialization.  Check that the backend program &quot;gpsbabel&quot; is properly installed and is in the current PATH

This program cannot continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input and output formats do not support %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input does not support %1; output format supports %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input format supports %1; output format does not support %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Both input and output formats support %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>waypoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no input options for format &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no output options for format &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No valid waypoints/routes/tracks translation specified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No input file specified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No valid output specified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No output file specified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process &quot;%1&quot; did not start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process exited unsucessfully with code %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error running gpsbabel: %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to reset all format options to default values?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One or more data filters are active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No data filters are active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visit Website...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make a Donation...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GPSBabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Map</name>
    <message>
        <source>Missing &quot;gmapbase.html&quot; file.  Check installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to load Google maps base page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MiscFltWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Misc. Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nuke (Remove) Data Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waypoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert routes, waypoints and tracks to different types.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This filter can be used to convert GPS data between different data types.

Some GPS data formats support only some subset of waypoints, tracks, and routes. The transform filter allows you to convert between these types. For example, it can be used to convert a pile of waypoints (such as those from a CSV file) into a track or vice versa. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type of transformation. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete original data after transform to prevent duplicated data. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swap Longitude and Latitudes for badly formatted data formats.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simple filter to swap the coordinate values (latitude and longitude) of all points. This can be helpful for wrong defined/coded data. Or if you think, you can use one of our xcsv formats, but latitude and longitude are in opposite order. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swap Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionsDlg</name>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>GPSBabel Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for newer version on start.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Anonymously report usage data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabled Formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore mismatch between command line and GUI version.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProcessWaitDialog</name>
    <message>
        <source>Process failed to start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process crashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process timedout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error while trying to write to process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error while trying to read from process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown process error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ... Process GPSBabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process did not terminate successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process crashed whle running</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Error processing formats from running process &quot;gpsbabel -^3&quot; at line %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RtTrkWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simplify routes and tracks by removing points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The Simplify filter is used to simplify routes and tracks for use with formats that limit the number of points they can contain or just to reduce the complexity of a route. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The filter attempts to remove points from each route until the number of points or the error is within the given bounds, while also attempting to preserve the shape of the original route as much as possible. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The quality of the results will vary depending on the density of points in the original route and the length of the original route. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Routes &amp; Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simplify route by removing points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> The Simplify filter is used to simplify routes and tracks for use with formats that limit the number of points they can contain or just to reduce the complexity of a route.

The filter attempts to remove points from each route until the number of points or the error is within the given bounds, while also attempting to preserve the shape of the original route as much as possible.

The quality of the results will vary depending on the density of points in the original route and the length of the original route. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simplify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum number points in track or route. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverse tracks and routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The reversal is performed in the laziest way possible. Timestamps are kept with the original waypoints so the resulting track or route will have the interesting characteristic that time runs backwards. This tends to make Magellan Mapsend, in particular, do a wierd thing and place each waypoint on a separate day. 
Additionally, if you&apos;re using this to reverse a route that navigates, say, an exit ramp or a one way street, you will be in for unpleasant ride. application cares about timestamps </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackWidget</name>
    <message>
        <source>Track Filter Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This filter performs various operations on track data. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Track Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Basic title for track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Basic title for new track(s). 
This option specifies a title for tracks generated by the track filter. By default, the title of the new track is composed of the start time of the track appended to this value. 
If this value contains a percent (%) character, it is treated as a format string for the POSIX strftime function, allowing custom time-based track names. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>the title of the new track is composed of the start time of the track appended to this value. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Correct track point timestamps by specified amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Correct trackpoint timestamps by a delta. 
This option changes the time of all trackpoints. This might be useful if your track must be moved by one or more hours because of an incorrect time zone. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>secs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use track pts. after this time. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use only track points after this timestamp.

This option is used along with the stop to discard trackpoints that were recorded outside of a specific period of time. This option specifies the beginning of the time period. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If checked, time specified here is based on this computer&apos;s current time zone. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If checked, the times specified here are based on the local computer&apos;s time zone.  Otherwise it is UTC.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use track pts before this time. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Use only track points before this timestamp.

This option is used in conjunction with the start option to discard all trackpoints outside of a given period of time. This option defines the end of the time period. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pack all tracks into one. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pack all tracks into one.

This option causes all tracks to be appended to one another to form a single track. This option does not work if any two tracks overlap in time; in that case, consider using the merge option.

This option is most useful for rejoining tracks that might have been interrupted by an equipment malfunction or an overnight stop. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge multiple tracks for the same way.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Merge multiple tracks for the same way.

This option puts all track points from all tracks into a single track and sorts them by time stamp. Points with identical time stamps will be dropped. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split by Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split by Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If nonzero, the track will be split if the time between two points is greater than this parameter.   If zero, the track will be split by date. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hrs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split by Dist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If nonzero, the input track will be split into several tracks if the distance between successive track points is greater than the distance given as a parameter. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>km</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GPS Fixes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dgps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synthesize speed. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synthesize speed.

This option computes a value for the GPS speed at each trackpoint. This is most useful with trackpoints from formats that don&apos;t support speed information or for trackoints synthesized by the interpolate filter. The speed at each trackpoint is the average speed from the previous trackpoint (distance divided by time). The first trackpoint in each track is assigned a speed of &quot;unknown.&quot; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synthesize course.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synthesize course.

This option computes (or recomputes) a value for the GPS heading at each trackpoint. This is most useful with trackpoints from formats that don&apos;t support heading information or for trackpoints synthesized by the interpolate filter. The heading at each trackpoint is simply the course from the previous trackpoint in the track. The first trackpoint in each track is arbitrarily assigned a heading of 0 degrees. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Course</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Upgrade</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpgradeCheck</name>
    <message>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download failed: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A new version of GPSBabel is available.&lt;br /&gt;Your version is %1 &lt;br /&gt;The latest version is %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you wish to download an upgrade?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid return data at line %1: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unexpected reply.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download failed: %1: %2.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VersionMismatch</name>
    <message>
        <source>GPSBabel Version Mismatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;A version mismatch has been detected.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GPSBabel command line version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GPSBabel GUI version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never show this message again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WayPtsWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waypoints Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove duplicates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The duplicate filter is designed to remove duplicate points based on their short name (traditionally a waypoint&apos;s name on the GPS receiver), and/or their location (to a precision of 6 decimals). This filter supports two options that specify how duplicates will be recognized, shortname and location. Generally, at least one of these options is required. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Suppress duplicate waypoints based on name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Suppress duplicate waypoints based on name. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This option is the one most often used with the duplicate filter. This option instructs the duplicate filter to remove any waypoints that share a short name with a waypoint that has come before. This option might be used to remove duplicates if you are merging two datasets that were each created in part from a common ancestor dataset. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Short Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Suppress duplicate waypoint based on coords. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Suppress duplicate waypoint based on coords. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This option causes the duplicate filter to remove any additional waypoint that has the same coordinates (to six decimal degrees) as a waypoint that came before. This option may be used to remove duplicate waypoints if the names are not expected to be the same. It also might be used along with the &lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;shortname&lt;/span&gt; option to remove duplicate waypoints if the names of several unrelated groups of waypoints might be the same. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove points based on proximity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum positional distance.

This option specifies the minimum allowable distance between two points. If two points are closer than this distance, only one of them is kept. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum positional distance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Feet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include points only within radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This filter includes or excludes waypoints based on their proximity to a central point. All waypoints more than the specified distance from the specified point will be removed from the dataset.

By default, all remaining points are sorted so that points closer to the center appear earlier in the output file. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum distance from center. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Miles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>km</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lat.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latitude of the central point in decimal degrees.  South latitudes should be expressed as a negative number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Long.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longitude of the central point in decimal degrees. West longitudes should be expressed as a negative number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This filter sorts waypoints into alphabetical order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
