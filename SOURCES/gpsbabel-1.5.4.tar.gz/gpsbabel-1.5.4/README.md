# GPSBabel
This is the source code for [GPSBabel](http://www.gpsbabel.org), the free software project to
manage GPS data (waypoints, tracks, routes) in your GPSes or in related programs.

##News 
We moved the source here on July 31 because [Google Code is shutting 
down](http://google-opensource.blogspot.com/2015/03/farewell-to-google-code.html) and 
there is a large inertia in the open source world for Git in general and Github specifically.  
As a result, some of our doc with our last release will now point to links on code.google.com
that will no longer work.  If you find doc that is out of date, please let us know.  (Better yet,
please send pull requests with fixes.)

Chief Babel-Head
@robertlipe
