#ifndef gbser_win_h
#define gbser_win_h

DWORD  mkspeed(unsigned br);

#endif
