/*
 * gbversion.h is generated from gbversion.h.in which uses autoconf voodoo
 * to get the version number from configure.in.
 *
 * Isn't simplification via automation grand?
 */
#define VERSION "1.5.4"
#define WEB_DOC_DIR "http://www.gpsbabel.org/htmldoc-1.5.4"
